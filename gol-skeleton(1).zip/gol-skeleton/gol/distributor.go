package gol

import (
	"fmt"
	"log"
	"net/rpc"
	"os"
	"strconv"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

type distributorChannels struct {
	events     chan<- Event
	ioCommand  chan<- ioCommand
	ioIdle     <-chan bool
	ioFilename chan<- string
	ioOutput   chan<- uint8
	ioInput    <-chan uint8
	keyPress   <-chan rune
}

type DistributedController struct {
	brokerAddress string
	rpcClient     *rpc.Client
	turn          int
	paused        bool
	quit          bool
}

func NewDistributedController(brokerAddress string) *DistributedController {
	log.Printf("[Controller] 🔗 Attempting to connect to broker at %s...", brokerAddress)
	client, err := rpc.Dial("tcp", brokerAddress)
	if err != nil {
		panic(fmt.Sprintf("failed to connect to broker at %s: %v", brokerAddress, err))
	}

	return &DistributedController{
		brokerAddress: brokerAddress,
		rpcClient:     client,
		turn:          0,
		paused:        false,
		quit:          false,
	}

}

func (dc *DistributedController) getGameState() (*util.GameStateResponse, error) {
	req := util.GameStateRequest{}
	var resp util.GameStateResponse
	if err := dc.rpcClient.Call(util.GetStateMethod, req, &resp); err != nil {
		return nil, fmt.Errorf("failed to get state %v", err)
	}
	return &resp, nil
}

func readInitialWorld(p Params, c distributorChannels) [][]uint8 {
	c.ioCommand <- ioInput
	c.ioFilename <- strconv.Itoa(p.ImageWidth) + "x" + strconv.Itoa(p.ImageHeight)

	world := make([][]uint8, p.ImageHeight)
	for i := range world {
		world[i] = make([]uint8, p.ImageWidth)
	}

	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			world[y][x] = <-c.ioInput
		}
	}

	return world
}

func getAliveCells(world [][]uint8, width, height int) []util.Cell {
	var aliveCells []util.Cell
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			if world[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{X: x, Y: y})
			}
		}
	}
	return aliveCells
}

// distributor divides the work between workers and interacts with other goroutines.
func distributor(p Params, c distributorChannels) {

	// TODO: Create a 2D slice to store the world.
	brokerAddress := os.Getenv("BROKER_ADDRESS")
	if brokerAddress == "" {
		brokerAddress = "localhost:8080"
	}
	log.Printf("[Controller] brokerAddress = %s", brokerAddress)
	world := readInitialWorld(p, c)

	initialAliveCells := getAliveCells(world, p.ImageWidth, p.ImageHeight)

	for _, cell := range initialAliveCells {
		c.events <- CellFlipped{CompletedTurns: 0, Cell: cell}
	}

	turn := 0
	c.events <- StateChange{turn, Executing}

	controller := NewDistributedController(brokerAddress)
	if controller == nil {
		panic("no broker found")
	}

	distParams := util.Params{
		Turns:       p.Turns,
		Threads:     p.Threads,
		ImageWidth:  p.ImageWidth,
		ImageHeight: p.ImageHeight,
	}

	startReq := util.StartGameRequest{
		Params: distParams,
		World:  world,
	}

	var startResp util.StartGameResponse
	log.Printf("try to connect with %v", util.StartGameMethod)
	if err := controller.rpcClient.Call(util.StartGameMethod, startReq, &startResp); err != nil {
		log.Printf("[Controller] Failed to start simulation: %v\n", err)
		return
	}
	log.Printf("connect to broker succesfully")

	if !startResp.Success {
		log.Printf("[Controller] Broker reject start %s\n", startResp.Message)
		return
	}

	ticker := time.NewTicker(2 * time.Second)
	// quit := false
	// paused := false
	defer ticker.Stop()

	for turn < p.Turns {
		select {

		case <-ticker.C:
			log.Printf("execute count")
			state, err := controller.getGameState()
			if err == nil {
				c.events <- AliveCellsCount{CompletedTurns: state.Turn, CellsCount: len(state.AliveCells)}
			}

		default:
			log.Printf("execute turn %v", turn)
			req := util.ExecuteTurnRequest{World: world}
			var res util.ExecuteTurnResponse

			log.Printf("[Distributor] 📤 Sending turn %d to broker", turn+1)
			// excute a turn of game,do flip for one time
			err := controller.rpcClient.Call(util.ExecuteTurnMethod, req, &res)
			if err != nil {
				log.Printf("RPC call failed: %v", err)
				time.Sleep(10 * time.Millisecond)
				continue
			}
			log.Printf("[Distributor] 📥 Received response for turn %d, success: %v", turn+1, res.Success)

			// decrease bandwidth consumption update according to flipped cells
			if res.Success {
				if len(res.FllippedCells) > 0 {
					for _, cell := range res.FllippedCells {
						if world[cell.Y][cell.X] == 0 {
							world[cell.Y][cell.X] = 255
						} else {
							world[cell.Y][cell.X] = 0
						}
					}
				}

				turn++
				c.events <- TurnComplete{CompletedTurns: turn}
				log.Printf("[Distributor] ✅ Turn %d completed", turn)

			} else {
				log.Printf("Broker returned error: %s", res.Message)
				time.Sleep(10 * time.Millisecond)
			}

		}
	}

	// 游戏结束后发送最终状态
	// get final cell state from broker
	finalState, err := controller.getGameState()
	if err != nil {
		log.Printf("Failed to get final state: %v", err)
		aliveCells := getAliveCells(world, p.ImageWidth, p.ImageHeight)
		c.events <- FinalTurnComplete{
			CompletedTurns: turn,
			Alive:          aliveCells,
		}
	} else {
		c.events <- FinalTurnComplete{
			CompletedTurns: finalState.Turn,
			Alive:          finalState.AliveCells,
		}
	}

	filename := fmt.Sprintf("%vx%vx%v", p.ImageWidth, p.ImageHeight, turn)
	c.ioCommand <- ioOutput
	c.ioFilename <- filename

	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			c.ioOutput <- world[y][x]
		}
	}

	// TODO: Execute all turns of the Game of Life.

	// TODO: Report the final state using FinalTurnCompleteEvent.

	// Make sure that the Io has finished any output before exiting.
	c.ioCommand <- ioCheckIdle
	<-c.ioIdle

	c.events <- StateChange{turn, Quitting}

	// Close the channel to stop the SDL goroutine gracefully. Removing may cause deadlock.
	close(c.events)
}
