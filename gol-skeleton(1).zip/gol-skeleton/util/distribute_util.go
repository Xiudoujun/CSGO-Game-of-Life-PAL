package util

const (
	GetStateMethod    = "BrokerOps.GetState"
	StartGameMethod   = "BrokerOps.StartGame"
	ExecuteTurnMethod = "BrokerOps.ExecuteTurn"
	QuitGameMethod    = "BrokerOps.QuitGame"

	// worker rpc method
	ProcessWorkMethod    = "WorkerOps.ProcessWork"
	RegisterWorkerMethod = "BrokerOps.RegisterWorker"
)

type ControlRequest struct {
	Command string `json:"command"`
}

type ControlResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
}

type Params struct {
	Turns       int
	Threads     int
	ImageWidth  int
	ImageHeight int
}

type GameState struct {
	Turn       int       `json:"turn"`
	Paused     bool      `json:"paused"`
	World      [][]uint8 `json:"world"`
	AliveCells []Cell    `json:"alive_cells"`
	Params     Params    `json:"params"`
}

type GameStateRequest struct {
}

type GameStateResponse struct {
	Turn         int       `json:"turn"`
	Paused       bool      `json:"paused"`
	World        [][]uint8 `json:"world"`
	AliveCells   []Cell    `json:"alive_cells"`
	FlippedCells []Cell    `json:"flipped_cells"` // 添加翻转的细胞信息
	Params       Params    `json:"params"`
	Finished     bool      `json:"finished"`
}

type StartGameRequest struct {
	Params Params    `json:"params`
	World  [][]uint8 `json:"world"`
}

type StartGameResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message`
}

type ExecuteTurnRequest struct {
	World [][]uint8 `json:"world"`
}

type ExecuteTurnResponse struct {
	Success       bool   `json:"success"`
	Message       string `json:"message"`
	FllippedCells []Cell `json:"flipped_cells"`
	Finished      bool   `json:"finished"`
}

type WorkerRegisterRequest struct {
	Address string `json:"address"`
	Port    int    `json:"port"`
}

type WorkerRegisterResponse struct {
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	WorkerID string `json:"worker_id"`
}

type WorkRequest struct {
	TaskID   string    `json:"task_id"`
	Turn     int       `json:"turn"`
	StartRow int       `json:"start_row"`
	EndRow   int       `json:"end_row"`
	World    [][]uint8 `json:"world"`
	Width    int       `json:"width"`
	Height   int       `json:"height"`
}

type WorkResponse struct {
	TaskID       string    `json:"task_id"`
	Turn         int       `json:"turn"`
	StartRow     int       `json:"start_row"`
	EndRow       int       `json:"end_row"`
	FlippedCells []Cell    `json:"flipped_cells"`
	NewRows      [][]uint8 `json:"new_rows"`
	Success      bool      `json:"success"`
	Error        string    `json:"error,omitempty"`
}

type PingRequest struct {
	Timestamp int64 `json:"timestamp"`
}

type PingResponse struct {
	Alive     bool  `json:"alive"`
	Timestamp int64 `json"timestamp"`
}

func CountAliveNeighbors(world [][]uint8, x, y, width, height int) int {
	// 预计算边界条件，避免重复的模运算
	x_prev := (x - 1 + width) % width
	x_next := (x + 1) % width
	y_prev := (y - 1 + height) % height
	y_next := (y + 1) % height

	// 直接访问8个邻居，检查是否为活细胞(255)
	count := 0
	if world[y_prev][x_prev] == 255 {
		count++
	} // 左上
	if world[y_prev][x] == 255 {
		count++
	} // 正上
	if world[y_prev][x_next] == 255 {
		count++
	} // 右上
	if world[y][x_prev] == 255 {
		count++
	} // 正左
	if world[y][x_next] == 255 {
		count++
	} // 正右
	if world[y_next][x_prev] == 255 {
		count++
	} // 左下
	if world[y_next][x] == 255 {
		count++
	} // 正下
	if world[y_next][x_next] == 255 {
		count++
	} // 右下

	return count
}

var LiveTable = [2][9]uint8{
	//        0   1   2     3     4   5   6   7   8  (邻居数量)
	{0, 0, 0, 255, 0, 0, 0, 0, 0},   // 死细胞: 只有3个邻居时复活
	{0, 0, 255, 255, 0, 0, 0, 0, 0}, // 活细胞: 2-3个邻居时存活
}
