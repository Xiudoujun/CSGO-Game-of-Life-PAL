package main

import (
	"flag"
	"fmt"
	"log"
	"net"
	"net/rpc"
	"sync"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

type BrokerOps struct {
	gameState        util.GameState
	workers          map[string]*WorkerConnection
	mutex            sync.Mutex
	running          bool
	workerCount      int
	gameLoopDone     chan bool
	stopGamepLoop    chan bool
	lastFllipedCells []util.Cell
}

type WorkerConnection struct {
	Address   string
	RpcClient *rpc.Client
	LastSeen  time.Time
	Active    bool
	WorkerID  string
}

func NewWorker() *BrokerOps {
	return &BrokerOps{
		workers:          make(map[string]*WorkerConnection),
		running:          false,
		gameLoopDone:     make(chan bool, 1),
		stopGamepLoop:    make(chan bool, 1),
		lastFllipedCells: make([]util.Cell, 0),
	}
}

// controller to broker, start a whole round of game with p.Turns
func (b *BrokerOps) StartGame(req util.StartGameRequest, res *util.StartGameResponse) error {
	b.mutex.Lock()
	defer b.mutex.Unlock()

	log.Printf("[Broker] 📥 Received StartGame request")
	log.Printf("[Broker] 📋 Game params: %dx%d, %d turns, %d threads",
		req.Params.ImageWidth, req.Params.ImageHeight, req.Params.Turns, req.Params.Threads)

	if b.running {
		log.Printf("[Broker] ⏹️  Stopping current game loop...")
		select {
		case b.stopGamepLoop <- true:
		default:
		}

		select {
		case <-b.gameLoopDone:
			log.Printf("[Broker] ✅ Previous game loop stopped")
		case <-time.After(50 * time.Millisecond):
			log.Printf("[Broker] ⚠️  Timeout waiting for game loop to stop, continuing...")
		}
	}
	b.gameState = util.GameState{
		Turn:   0,
		Paused: false,
		World:  req.World,
		Params: req.Params,
	}

	aliveCells := []util.Cell{}
	for y := 0; y < req.Params.ImageHeight; y++ {
		for x := 0; x < req.Params.ImageWidth; x++ {
			if req.World[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{X: x, Y: y})
			}
		}
	}
	b.gameState.AliveCells = aliveCells

	log.Printf("[Broker] 🧮 Initial alive cells: %d", len(aliveCells))
	// log.Printf("[Broker] 👥 Active workers: %d", len(b.getActiveWorkers()))

	b.running = true
	res.Success = true
	res.Message = fmt.Sprintf("Game started with %d alive cells", len(aliveCells))

	log.Printf("[Broker] ✅ Game started successfully")
	return nil
}

// controller to broker, excute a turn of update for designated world
func (b *BrokerOps) ExecuteTurn(req *util.ExecuteTurnRequest, res *util.ExecuteTurnResponse) error {
	b.mutex.Lock()
	defer b.mutex.Unlock()

	if !b.running {
		res.Success = false
		res.Message = "Game not started"
		return nil
	}

	if b.gameState.Turn >= b.gameState.Params.Turns {
		res.Success = true
		res.Finished = true
		res.Message = "Game already finished"
		return nil
	}

	currentWorld := req.World
	imageHeight := b.gameState.Params.ImageHeight
	imageWidth := b.gameState.Params.ImageWidth

	log.Printf("[Broker] 🎯 Executing turn %d with received world state", b.gameState.Turn+1)

	flippedCells := b.processWorldWithWorkers(currentWorld, imageWidth, imageHeight)
	b.gameState.Turn++
	b.lastFllipedCells = flippedCells

	newWorld := make([][]uint8, imageHeight)
	for i := range newWorld {
		newWorld[i] = make([]uint8, imageWidth)
		copy(newWorld[i], currentWorld[i])
	}

	// 更新 broker world 状态，应用fllippedCells
	for _, cell := range flippedCells {
		if newWorld[cell.Y][cell.X] == 0 {
			newWorld[cell.Y][cell.X] = 255
		} else {
			newWorld[cell.Y][cell.X] = 0
		}
	}

	b.gameState.World = newWorld

	var aliveCells []util.Cell
	for y := 0; y < imageHeight; y++ {
		for x := 0; x < imageWidth; x++ {
			if newWorld[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{Y: y, X: x})
			}
		}
	}

	b.gameState.AliveCells = aliveCells

	res.Success = true
	res.FllippedCells = flippedCells
	res.Finished = b.gameState.Turn >= b.gameState.Params.Turns
	res.Message = fmt.Sprintf("Turn %d completed", b.gameState.Turn)

	log.Printf("[Broker] ✅ Turn %d completed, %d flipped cells, %d alive cells",
		b.gameState.Turn, len(flippedCells), len(aliveCells))

	return nil

}

// controller send request to get new state from broker
func (b *BrokerOps) GetState(req util.GameStateRequest, resp *util.GameStateResponse) error {
	b.mutex.Lock()
	defer b.mutex.Unlock()

	// update the newest turn and cell message and response to controller
	resp.Turn = b.gameState.Turn
	resp.Paused = b.gameState.Paused
	resp.World = b.gameState.World
	resp.AliveCells = b.gameState.AliveCells
	resp.FlippedCells = b.lastFllipedCells
	resp.Params = b.gameState.Params
	resp.Finished = !b.running || b.gameState.Turn >= b.gameState.Params.Turns

	return nil
}

// worker send message to broekr
// deal with worker'register
// new worker elastic saclability
func (b *BrokerOps) RegisterWorker(req util.WorkerRegisterRequest, resp *util.WorkerRegisterResponse) error {
	// keep data's consistency
	b.mutex.Lock()
	defer b.mutex.Unlock()
	// check whether the node reigtered
	if existingWorker, exist := b.workers[req.Address]; exist {
		// update alive time if registered
		existingWorker.LastSeen = time.Now()
		existingWorker.Active = true
		log.Printf("[Broker] 💓 Worker heartbeat updated: %s", req.Address)

		resp.Success = true
		resp.Message = "Worker heartbeat updated"
		resp.WorkerID = existingWorker.WorkerID
		// stop the goroutine
		return nil
	}

	log.Printf("[Broker] 🔗 New worker registration attempt: %s", req.Address)
	// try to create connection worker
	client, err := rpc.Dial("tcp", req.Address)
	if err != nil {
		log.Printf("[Broker] failed to connect worker %s: %v", req.Address, err)
		resp.Success = false
		resp.Message = fmt.Sprintf("Failed to connect to worker %v", err)
	}
	b.workerCount++
	workerID := fmt.Sprintf("worker_%d", b.workerCount)
	worker := &WorkerConnection{
		Address:   req.Address,
		RpcClient: client,
		LastSeen:  time.Now(),
		Active:    true,
		WorkerID:  workerID,
	}

	// add worker to workers register table if recieve response from worker
	b.workers[req.Address] = worker
	log.Printf("Broker] ✅ New worker registered:%s ID %s", req.Address, workerID)
	log.Printf("[Broker] 👥 Total workers: %d", len(b.workers))

	resp.Success = true
	resp.Message = "worekr register successfully"
	resp.WorkerID = workerID

	return nil

}

func (b *BrokerOps) sendTaskToWorker(worker *WorkerConnection, task util.WorkRequest, responses chan<- util.WorkResponse) {
	var response util.WorkResponse
	err := worker.RpcClient.Call(util.ProcessWorkMethod, task, &response)
	log.Printf("send task to %v", worker.WorkerID)
	if err != nil {
		log.Printf("Failed to send task to worker %s: %v", worker.WorkerID, err)
		worker.Active = false
		response = util.WorkResponse{
			TaskID:  task.TaskID,
			Turn:    task.Turn,
			Success: false,
			Error:   fmt.Sprintf("Worker communication failed: %v", err),
		}
	} else {
		worker.LastSeen = time.Now()
	}

	responses <- response
}

func (b *BrokerOps) getActiveWorkers() []*WorkerConnection {
	var active []*WorkerConnection
	now := time.Now()

	for _, worker := range b.workers {
		log.Printf("worker message %v", *worker)
		if worker.Active && now.Sub(worker.LastSeen) < 30*time.Second {
			active = append(active, worker)
		} else if worker.Active {
			log.Printf("Worker %s timed out, marking as inactive", worker.WorkerID)
			worker.Active = false
		}

	}

	return active
}

func (b *BrokerOps) processWorldWithWorkers(world [][]uint8, imageWidth, imageHeight int) []util.Cell {
	activeWorkers := b.getActiveWorkers()
	if len(activeWorkers) == 0 {
		log.Printf("[Broker] ⚠️  No active workers available")
		return []util.Cell{}
	}

	numTasks := b.gameState.Params.Threads
	if numTasks > imageHeight {
		numTasks = imageHeight
	}
	rowsPerTask := imageHeight / numTasks
	responses := make(chan util.WorkResponse, numTasks)

	for i := 0; i < numTasks; i++ {
		startRow := i * rowsPerTask
		endRow := startRow + rowsPerTask
		if i == numTasks-1 {
			endRow = imageHeight
		}
		task := util.WorkRequest{
			TaskID:   fmt.Sprintf("turn_%d_task_%d", b.gameState.Turn+1, i),
			Turn:     b.gameState.Turn + 1,
			StartRow: startRow,
			EndRow:   endRow,
			World:    world,
			Width:    imageWidth,
			Height:   imageHeight,
		}

		worker := activeWorkers[i%len(activeWorkers)]
		go b.sendTaskToWorker(worker, task, responses)
	}

	var allFlippedCells []util.Cell
	completedTasks := 0
	for completedTasks < numTasks {
		select {
		case response := <-responses:
			fmt.Println(response.TaskID)
			completedTasks++
			if response.Success {
				allFlippedCells = append(allFlippedCells, response.FlippedCells...)
			}
		case <-time.After(5 * time.Second):
			log.Printf("Task timeout on turn %d", b.gameState.Turn+1)
			return []util.Cell{}
		}
	}
	return allFlippedCells
}

func main() {
	log.Printf("broker start")
	broker := NewWorker()

	var listenPort int
	// read the port
	flag.IntVar(
		&listenPort,
		"port",
		8080,
		"Specify the listen port for broker",
	)

	// public method, process work from other nodes
	err := rpc.Register(broker)
	if err != nil {
		log.Fatalf("[Broker] failed to register service %v", err)
	}

	listener, err := net.Listen("tcp", fmt.Sprintf(":%d", listenPort))
	if err != nil {
		log.Fatalf("[Broker] failed to listen to %d", listenPort)
	}

	defer listener.Close()
	rpc.Accept(listener)
}
