package main

import (
	"flag"
	"fmt"
	"log"
	"net"
	"net/rpc"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

type WorkerOps struct {
	address    string // 方便和 broker 通信，带address 验证信息
	brokerAddr string // broker 节点地址
	rpcClient  *rpc.Client
	running    bool
	workerID   string
}

func NewWorker(address, brokerAddr string) *WorkerOps {
	return &WorkerOps{
		address:    address,
		brokerAddr: brokerAddr,
		running:    true,
	}
}

// broker send task to worker
// 接收broker task ，返回更新 state
// 以 反转细胞形式发送更新结果，broker 是不要求接收的顺序，broekr 无序接收结果，完成更新
func (w *WorkerOps) ProcessWork(req util.WorkRequest, res *util.WorkResponse) error {
	log.Printf("[worker] received taks %v", req.TaskID)
	flippedCells, newRows := w.processGameOfLife(req)

	res.TaskID = req.TaskID
	res.Turn = req.Turn
	res.StartRow = req.StartRow
	res.EndRow = req.EndRow
	res.NewRows = newRows
	res.FlippedCells = flippedCells
	res.Success = true
	return nil
}

func (w *WorkerOps) processGameOfLife(req util.WorkRequest) ([]util.Cell, [][]uint8) {
	var flippedCells []util.Cell
	rowCount := req.EndRow - req.StartRow
	newRows := make([][]uint8, rowCount)
	for i := range newRows {
		newRows[i] = make([]uint8, req.Width)
	}

	for y := req.StartRow; y < req.EndRow; y++ {
		for x := 0; x < req.Width; x++ {
			currentCell := req.World[y][x]
			alive := util.CountAliveNeighbors(req.World, x, y, req.Width, req.Height)
			cellState := currentCell >> 7
			newState := util.LiveTable[cellState][alive]
			rowIndex := y - req.StartRow
			newRows[rowIndex][x] = newState
			if currentCell^newState != 0 {
				flippedCells = append(flippedCells, util.Cell{X: x, Y: y})
			}
		}
	}

	return flippedCells, newRows
}

// send register message to broker
func (w *WorkerOps) registerWithBroker() error {
	log.Printf("[worker] attempt to connect broker at %s", w.brokerAddr)
	client, err := rpc.Dial("tcp", w.brokerAddr)
	if err != nil {
		log.Printf("[Worker] ❌ Failed to connect to broker: %v", err)
		return fmt.Errorf("failed to connect broker %v", err)
	}
	w.rpcClient = client
	// send message contain ip:port, register in b.getActiveWorkers()
	req := util.WorkerRegisterRequest{
		Address: w.address,
	}
	log.Printf("sending registration to broker")
	var resp util.WorkerRegisterResponse
	err = client.Call(util.RegisterWorkerMethod, req, &resp)
	if err != nil {
		log.Printf("[Worker] failed to register with broker %v", err)
		return fmt.Errorf("[Worker] failed to register with broker %v", err)
	}
	if !resp.Success {
		log.Printf("[Worker] failed to register with broker %v", err)
		return fmt.Errorf("[Worker] failed to register with broker %v", err)
	}
	w.workerID = resp.WorkerID
	return nil
}

func (w *WorkerOps) startHeartbeat() {
	ticker := time.NewTicker(15 * time.Second)
	go func() {
		defer ticker.Stop()
		for w.running {
			<-ticker.C
			err := w.registerWithBroker()
			if err != nil {
				log.Printf("[%s] Heartbeat registration failed: %v", w.workerID, err)
			}

		}
	}()
}

// worker send heartbeat to broker
// heartbeat health check
func (w *WorkerOps) Ping(req util.PingRequest, resp *util.PingResponse) error {
	resp.Alive = w.running
	resp.Timestamp = time.Now().Unix()
	return nil
}

func (w *WorkerOps) Run() error {
	log.Printf("[Worker] start at %s", w.address)
	// register heartbeat and cell update
	err := rpc.Register(w)
	if err != nil {
		log.Printf("[Worker] failed to register rpc %v", err)
		return fmt.Errorf("[Worker] failed to register rpc %v", err)
	}
	listener, err := net.Listen("tcp", w.address)
	if err != nil {
		log.Printf("[Worker] failed to listen on %s", w.address)
		return fmt.Errorf("[Worker] failed to listen on %s", w.address)
	}
	defer listener.Close()
	// this goroutine is to process work recieved from broker
	go rpc.Accept(listener)
	time.Sleep(500 * time.Millisecond)

	if err := w.registerWithBroker(); err != nil {
		log.Printf("[Worker] Registeration failed %v", err)
		return fmt.Errorf("[Worker] Registeration failed %v", err)
	}
	// keep heartbeat with broker 证明节点的存活状态
	w.startHeartbeat()
	log.Printf("[Worker] worker %s successfully regisgtered", w.workerID)
	for w.running {
		time.Sleep(1 * time.Second)
	}
	log.Printf("[Worker] worker %s shutting down ", w.workerID)
	return nil

}

func main() {
	var brokerAddress string
	var workerPort int
	flag.IntVar(&workerPort, "port", 9090, "the port of worker")
	flag.StringVar(&brokerAddress, "broker", "localhost:8080", "broker address")
	flag.Parse()
	fmt.Println(workerPort)
	workerAddress := fmt.Sprintf("localhost:%d", workerPort)
	worker := NewWorker(workerAddress, brokerAddress)
	if err := worker.Run(); err != nil {
		log.Fatalf("Worker failed %v", err)
	}

}
