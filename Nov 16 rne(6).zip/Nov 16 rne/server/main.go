// 位于 server/main.go (Step 4 版本 - 添加了 Save 和 Reset)
package main

import (
	"log"
	"net"
	"net/rpc"
	"sync"

	"uk.ac.bris.cs/gameoflife/gol"
	"uk.ac.bris.cs/gameoflife/util"
)

// LogicEngine 是我们将要注册为 RPC 服务的结构体。
type LogicEngine struct {
	world [][]byte
	mutex sync.Mutex
}

// ProcessSingleTurn - (Step 3 的函数, 保持不变)
func (le *LogicEngine) ProcessSingleTurn(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	// (这部分和你的代码 100% 相同，用于处理逐帧更新)
	le.mutex.Lock()
	defer le.mutex.Unlock()

	// 我们的 3 个细胞的坐标
	c1 := util.Cell{X: 50, Y: 50}
	c2 := util.Cell{X: 50, Y: 51}
	c3 := util.Cell{X: 50, Y: 52}

	// 确保世界足够大
	if args.Params.ImageHeight <= 52 || args.Params.ImageWidth <= 52 {
		log.Println("World is too small for the 3-cell blinker!")
		// 保持世界为空
		if le.world == nil {
			le.world = make([][]byte, args.Params.ImageHeight)
			for i := range le.world {
				le.world[i] = make([]byte, args.Params.ImageWidth)
			}
		}
		reply.World = le.world
		reply.AliveCells = []util.Cell{}
		return nil
	}

	// 5. 检查世界是否已经创建 (是否是第一次调用?)
	if le.world == nil {
		// --- 第一次调用的逻辑 ---
		log.Printf("First call. Creating initial world with 3-cell blinker.\n")

		le.world = make([][]byte, args.Params.ImageHeight)
		for i := range le.world {
			le.world[i] = make([]byte, args.Params.ImageWidth)
		}

		// *** 修复 1: 启动所有 3 个细胞 (ON) ***
		le.world[c1.Y][c1.X] = 255
		le.world[c2.Y][c2.X] = 255
		le.world[c3.Y][c3.X] = 255

	} else {
		// --- 后续调用的逻辑 (计算一轮) ---

		// *** 修复 2: 一起闪烁 (ON/OFF) ***
		if le.world[c1.Y][c1.X] == 255 {
			// 它们现在是 ON, 把它们变成 OFF
			le.world[c1.Y][c1.X] = 0
			le.world[c2.Y][c2.X] = 0
			le.world[c3.Y][c3.X] = 0
		} else {
			// 它们现在是 OFF, 把它们变成 ON
			le.world[c1.Y][c1.X] = 255
			le.world[c2.Y][c2.X] = 255
			le.world[c3.Y][c3.X] = 255
		}
	}

	// 6. 填充 'reply' (返回当前的世界状态)

	var finalAliveCells []util.Cell
	// *** 修复 3: 报告所有 3 个活细胞 (如果它们是 ON) ***
	if le.world[c1.Y][c1.X] == 255 {
		finalAliveCells = []util.Cell{c1, c2, c3}
	}

	reply.World = le.world
	reply.AliveCells = finalAliveCells

	return nil
}

// -----------------------------------------------------------------
// ！！！ Step 4 新增函数 1: GetCurrentState (用于 's' 键保存) ！！！
// -----------------------------------------------------------------
// GetCurrentState 是一个新的 RPC 方法，它只读取当前状态，不推进模拟。
// 它使用了和 ProcessSingleTurn 相同的 reply 类型。
func (le *LogicEngine) GetCurrentState(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	log.Println("Received request for current state (Save)...")
	le.mutex.Lock()
	defer le.mutex.Unlock()

	// 检查世界是否存在
	if le.world == nil {
		log.Println("...State is nil, returning empty.")
		// 返回一个空的世界，而不是 nil
		reply.World = make([][]byte, args.Params.ImageHeight)
		for i := range reply.World {
			reply.World[i] = make([]byte, args.Params.ImageWidth)
		}
		reply.AliveCells = []util.Cell{}
		return nil
	}

	// --- 复制当前状态到 reply ---
	// (我们使用和 ProcessSingleTurn 相同的占位逻辑来计算活细胞)

	// 我们的 3 个细胞的坐标
	c1 := util.Cell{X: 50, Y: 50}
	c2 := util.Cell{X: 50, Y: 51}
	c3 := util.Cell{X: 50, Y: 52}

	var finalAliveCells []util.Cell
	// 检查它们是否在 (以防世界太小)
	if args.Params.ImageHeight > 52 && args.Params.ImageWidth > 52 {
		if le.world[c1.Y][c1.X] == 255 {
			finalAliveCells = []util.Cell{c1, c2, c3}
		}
	}

	reply.World = le.world
	reply.AliveCells = finalAliveCells

	log.Println("...Returning current state.")
	return nil
}

// -----------------------------------------------------------------
// ！！！ Step 4 新增函数 2: ResetState (用于 'q' 键退出) ！！！
// -----------------------------------------------------------------
// ResetState 是一个新的 RPC 方法，用于清空服务器状态。
// 我们可以复用 args 和 reply，即使我们不使用它们。
func (le *LogicEngine) ResetState(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	log.Println("Received request to reset state (Quit)...")
	le.mutex.Lock()
	defer le.mutex.Unlock()

	// 重置世界，为下一个客户端做准备
	le.world = nil

	log.Println("...Server state has been reset.")
	return nil
}

// main 是服务器的入口 (保持不变)
func main() {
	engine := new(LogicEngine)

	err := rpc.Register(engine)
	if err != nil {
		log.Fatal("Failed to register RPC engine:", err)
	}

	port := ":8080"
	listener, err := net.Listen("tcp", port)
	if err != nil {
		log.Fatal("Failed to listen on port", port, err)
	}
	defer listener.Close()

	log.Println("GoL Engine server listening on port", port)

	rpc.Accept(listener)
}
