// 位于 distributor/main.go (Step 6 - 真正并行版)
package main

import (
	"errors"
	"log"
	"net"
	"net/rpc"
	"sync"
	"time"

	"uk.ac.bris.cs/gameoflife/gol"
	"uk.ac.bris.cs/gameoflife/util"
)

// LogicEngine 结构体 (保持不变)
type LogicEngine struct {
	world           [][]uint8
	mutex           sync.Mutex
	workerAddresses []string
	params          gol.Params
}

// createInitialWorld 有问题
func createInitialWorld(p gol.Params) [][]byte {
	world := make([][]byte, p.ImageHeight)
	for i := range world {
		world[i] = make([]byte, p.ImageWidth)
	}

	// Glider
	if p.ImageHeight > 5 && p.ImageWidth > 5 {
		world[1][2] = 255
		world[2][3] = 255
		world[3][1] = 255
		world[3][2] = 255
		world[3][3] = 255
	}
	return world
}

// -----------------------------------------------------------------
// ！！！ Step 6 核心：重写 ProcessSingleTurn ！！！
// -----------------------------------------------------------------
// mod 是一个辅助函数，用于正确处理取模 (Go 的 % 运算符在处理负数时不是取模)。
// 我们从 gol/gol.go 复制这个函数。
func mod(x, m int) int {
	return (x%m + m) % m
}

// 客户端调用这个函数。它现在是"真正的"调度器。
func (le *LogicEngine) ProcessSingleTurn(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	log.Printf("Distributor: ProcessSingleTurn called")
	le.mutex.Lock()
	defer le.mutex.Unlock()

	if le.world == nil {
		log.Println("Distributor: First call. Receiving initial world from client...")
		le.params = args.Params

		if args.World == nil {
			return errors.New("initial world state must be provided by client")
		}

		le.world = make([][]uint8, le.params.ImageHeight)
		for i := range le.world {
			le.world[i] = make([]uint8, le.params.ImageWidth)
			copy(le.world[i], args.World[i])
		}
		log.Printf("Distributor: Initial world received, size %dx%d", le.params.ImageWidth, le.params.ImageHeight)
	}

	// 2. 准备并行调用 N 个 Workers
	numWorkers := len(le.workerAddresses)
	p := le.params

	// 检查是否有可用的workers
	if numWorkers == 0 {
		return errors.New("no workers configured")
	}

	var wg sync.WaitGroup
	newStrips := make([][][]byte, numWorkers)
	errChannel := make(chan error, numWorkers)

	// 3. 计算切分 (Split)
	baseStripHeight := p.ImageHeight / numWorkers
	remainder := p.ImageHeight % numWorkers

	currentStartRow := 0

	// 4. 循环，为每个 Worker 启动一个 Goroutine
	for i := 0; i < numWorkers; i++ {

		stripHeight := baseStripHeight
		if remainder > 0 {
			stripHeight++
			remainder--
		}

		startIndex := currentStartRow
		endIndex := currentStartRow + stripHeight
		currentStartRow = endIndex

		strip := make([][]byte, stripHeight)
		for y := 0; y < stripHeight; y++ {
			strip[y] = make([]byte, p.ImageWidth)
			copy(strip[y], le.world[startIndex+y])
		}

		// 4c. 计算边缘行 (Halos)
		haloUpIndex := mod(startIndex-1, p.ImageHeight)
		haloDoIndex := mod(endIndex, p.ImageHeight)

		haloUp := make([]byte, p.ImageWidth)
		haloDo := make([]byte, p.ImageWidth)
		copy(haloUp, le.world[haloUpIndex])
		copy(haloDo, le.world[haloDoIndex])

		// 4d. 准备此 worker 的 RPC 任务
		workerJob := gol.WorkerJobArgs{
			Params: p,
			Strip:  strip,
			HaloUp: haloUp,
			HaloDo: haloDo,
			Turn:   0,
		}

		workerAddr := le.workerAddresses[i]
		workerIndex := i // (在 goroutine 中捕获 'i' 的当前值)

		// 5. 启动 GOROUTINE
		wg.Add(1)
		go func(index int, addr string, job gol.WorkerJobArgs) {
			defer wg.Done()

			log.Printf("Distributor: Connecting to worker %d at %s", index, addr)

			var workerReply gol.WorkerJobReply

			workerClient, err := rpc.Dial("tcp", addr)
			if err != nil {
				log.Printf("Distributor: ERROR Failed to dial worker %s: %v", addr, err)
				select {
				case errChannel <- err:
				default:
				}
				return
			}
			defer workerClient.Close()

			log.Printf("Distributor: Sending task to worker %d", index)
			err = workerClient.Call("WorkerEngine.ProcessStrip", job, &workerReply)
			if err != nil {
				log.Printf("Distributor: ERROR Worker %s failed: %v", addr, err)
				select {
				case errChannel <- err:
				default:
				}
				return
			}

			log.Printf("Distributor: Worker %d completed successfully", index)
			newStrips[index] = workerReply.StripNew

		}(workerIndex, workerAddr, workerJob)
	}

	// 7. 等待所有 Goroutine 完成，带超时
	done := make(chan bool, 1)
	go func() {
		wg.Wait()
		done <- true
	}()

	// 等待完成或超时
	select {
	case <-done:
		log.Printf("Distributor: All workers completed successfully")
	case <-time.After(10 * time.Second):
		return errors.New("timeout waiting for workers to complete")
	}

	// 8. 检查是否有任何错误
	select {
	case err := <-errChannel:
		if err != nil {
			return errors.New("A worker failed during processing: " + err.Error())
		}
	default:
		// 没有错误
	}

	// 9. ！！！拼接 (Stitch) ！！！
	newWorld := make([][]uint8, 0, p.ImageHeight)
	for _, strip := range newStrips {
		newWorld = append(newWorld, strip...)
	}

	// 10. 更新服务器的“记忆”
	le.world = newWorld

	// 11. 准备返回给 *客户端* 的 reply
	reply.AliveCells = gol.CalculateAliveCells(p, le.world)
	reply.World = le.world

	return nil
}

// -----------------------------------------------------------------
// ！！！ Step 4 的函数 (保持不变) ！！！
// -----------------------------------------------------------------
// GetCurrentState, ResetState...
func (le *LogicEngine) GetCurrentState(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	log.Println("Distributor: Received request for current state (Save)...")
	le.mutex.Lock()
	defer le.mutex.Unlock()

	if le.world == nil {
		log.Println("...State is nil, returning empty.")
		reply.World = make([][]byte, args.Params.ImageHeight)
		for i := range reply.World {
			reply.World[i] = make([]byte, args.Params.ImageWidth)
		}
		reply.AliveCells = []util.Cell{}
		return nil
	}

	reply.AliveCells = gol.CalculateAliveCells(le.params, le.world)
	reply.World = le.world

	log.Println("...Returning current state.")
	return nil
}

func (le *LogicEngine) ResetState(args gol.ProcessTurnsArgs, reply *gol.ProcessTurnsReply) error {
	log.Println("Distributor: Received request to reset state (Quit)...")
	le.mutex.Lock()
	defer le.mutex.Unlock()
	le.world = nil // 重置世界
	log.Println("...Distributor state has been reset.")
	return nil
}

// -----------------------------------------------------------------
// ！！！ Step 6 Main - 我们现在使用 4 个 Workers ！！！
// -----------------------------------------------------------------
// main 是“调度器”服务器的入口
func main() {
	engine := new(LogicEngine)

	// ！！！定义我们的 Worker 在哪里！！！
	// (我们现在假设有 4 个 worker 在这些端口上运行)
	engine.workerAddresses = []string{
		"localhost:8081",
		// "localhost:8082",
		// "localhost:8083",
		// "localhost:8084",
	}

	log.Printf("Distributor: Initialized with %d worker(s)\n", len(engine.workerAddresses))

	// 注册 RPC 服务
	err := rpc.Register(engine)
	if err != nil {
		log.Fatal("Failed to register RPC distributor:", err)
	}

	// 调度器 (Distributor) 监听 8080 端口
	port := ":8080"
	listener, err := net.Listen("tcp", port)
	if err != nil {
		log.Fatal("Failed to listen on port", port, err)
	}
	defer listener.Close()

	log.Println("GoL Distributor server listening on port", port)

	// 接受并处理 *客户端* 的连接
	rpc.Accept(listener)
}
