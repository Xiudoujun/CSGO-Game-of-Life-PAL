// 位于 gol/rpc_types.go (Step 5 升级版)
package gol

import (
	"uk.ac.bris.cs/gameoflife/util"
)

// -----------------------------------------------------------------
// Step 1-4 类型 (用于 Client <-> Distributor)
// (这些保持不变)
// -----------------------------------------------------------------

// ProcessTurnsArgs 是 RPC 调用的参数。
// 客户端 (main.go) 会发送这个
type ProcessTurnsArgs struct {
	Params Params    // 包含 Turns, ImageWidth, ImageHeight 等
	World  [][]uint8 // 在 Step 1 中，客户端可以发送 nil
}

// ProcessTurnsReply 是 RPC 调用的返回值。
// 服务器 (server/main.go 或 distributor.go) 会返回这个
type ProcessTurnsReply struct {
	World      [][]uint8   // 最终的世界状态
	AliveCells []util.Cell // 活细胞列表
}

// -----------------------------------------------------------------
// ！！！ Step 5 新增类型 (用于 Distributor <-> Worker) ！！！
// -----------------------------------------------------------------

// WorkerJobArgs 定义了“调度器”发送给“工作节点”的任务
type WorkerJobArgs struct {
	Params Params    // GOL 参数
	Strip  [][]uint8 // 工作节点自己的条带 (e.g., 256 高 x 512 宽)
	HaloUp []uint8   // 上方邻居的"边缘行" (Ghost Row) (1 x 512 宽)
	HaloDo []uint8   // 下方邻居的"边缘行" (Ghost Row) (1 x 512 宽)
	Turn   int       // 当前轮次 (用于日志)
}

// WorkerJobReply 定义了"工作节点"返回给"调度器"的结果
type WorkerJobReply struct {
	StripNew [][]uint8 // 工作节点计算出的 *新* 条带
}
