package gol

import "uk.ac.bris.cs/gameoflife/util"

// Params 提供了 GOL 运行的详细信息。
// 这是我们需要保留的。
type Params struct {
	Turns       int
	Threads     int
	ImageWidth  int
	ImageHeight int
}

// -----------------------------------------------------------------
// ！！！ 真正的 GOL 核心逻辑 (我们需要这些) ！！！
// -----------------------------------------------------------------

// mod 是一个辅助函数，用于正确处理取模。
func mod(x, m int) int {
	return (x%m + m) % m
}

// CalculateNeighbours 是 GOL 的核心。
// 它计算一个给定细胞 (x, y) 在 'world' 中有多少个活着的邻居。
// 它正确地处理“环绕” (toroidal) 边界。
func CalculateNeighbours(p Params, world [][]byte, x, y int) int {
	neighbours := 0
	for i := -1; i <= 1; i++ {
		for j := -1; j <= 1; j++ {
			if i == 0 && j == 0 {
				continue // 跳过细胞自身
			}
			// 使用 mod 来正确环绕边界
			nx := mod(x+j, p.ImageWidth)
			ny := mod(y+i, p.ImageHeight)

			// 检查邻居是否活着 (非 0)
			if world[ny][nx] != 0 {
				neighbours++
			}
		}
	}
	return neighbours
}

// CalculateNextState 是 GOL 的“引擎”。
// 它接收一个 'world'，并返回下一轮的 'newWorld'。
// (这个函数我们的 Distributor 和 Worker 实际上没有直接调用，
// 但保留它没有坏处，它展示了 GOL 的完整逻辑。)
func CalculateNextState(p Params, world [][]byte) [][]byte {
	// 创建一个新的 2D 切片来存储下一轮的状态
	newWorld := make([][]byte, p.ImageHeight)
	for i := range newWorld {
		newWorld[i] = make([]byte, p.ImageWidth)
	}

	// 遍历世界中的每一个细胞
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			neighbours := CalculateNeighbours(p, world, x, y)
			currentState := world[y][x]

			// 应用 GOL 规则
			if currentState == 255 { // 细胞是活的
				if neighbours < 2 || neighbours > 3 {
					newWorld[y][x] = 0 // 1. 孤独或拥挤，死亡
				} else {
					newWorld[y][x] = 255 // 2. 存活
				}
			} else { // 细胞是死的
				if neighbours == 3 {
					newWorld[y][x] = 255 // 3. 复活
				} else {
					newWorld[y][x] = 0 // 4. 保持死亡
				}
			}
		}
	}
	return newWorld
}

// CalculateAliveCells 遍历世界并返回所有活细胞的坐标。
// 这是我们的 Distributor (调度器) 需要的。
func CalculateAliveCells(p Params, world [][]byte) []util.Cell {
	aliveCells := []util.Cell{}
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if world[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{X: x, Y: y})
			}
		}
	}
	return aliveCells
}

func Run(p Params, e chan<- Event, keypresses <-chan rune) {
	runClient(p, e, keypresses)
}

