package gol

import (
	"fmt"
	"log"
	"net/rpc"
	"os"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

// -----------------------------------------------------------------
// ！！！ Step 4 新增函数: saveState ！！！
// -----------------------------------------------------------------
// saveState 是一个辅助函数，用于调用服务器、获取当前状态并保存 PGM 文件
func saveState(client *rpc.Client, args ProcessTurnsArgs, events chan<- Event, currentTurn int) {

	log.Println("[Client] Requesting current state from server for saving...")
	var reply ProcessTurnsReply

	// 1. 调用新的 "GetCurrentState" RPC 方法
	err := client.Call("LogicEngine.GetCurrentState", args, &reply)
	if err != nil {
		log.Printf("[Client] ERROR: Failed to get current state: %v", err)
		return
	}

	// 2. 创建文件名
	filename := fmt.Sprintf("turn_%d.pgm", currentTurn)
	log.Printf("[Client] Saving state to %s", filename)

	err = OutputPGM(filename, reply.World)
	if err != nil {
		log.Printf("[Client] ERROR: Failed to save PGM: %v", err)
		return
	}

	// 4. 发送事件通知 GUI
	events <- ImageOutputComplete{
		CompletedTurns: currentTurn,
		Filename:       filename,
	}
	log.Printf("[Client] Save complete: %s", filename)
}

// -----------------------------------------------------------------
// ！！！ Step 4 升级函数: runClient ！！！
// -----------------------------------------------------------------
func runClient(params Params, events chan<- Event, keyPresses <-chan rune) {
	log.Printf("[Client] Starting with params: Turns=%d, Width=%d, Height=%d", params.Turns, params.ImageWidth, params.ImageHeight)
	serverAddr := os.Getenv("BROKER_ADDRESS")
	if serverAddr == "" {
		serverAddr = "localhost:8080"
	}
	log.Printf("[Client] Connecting to server at %s", serverAddr)
	client, err := rpc.Dial("tcp", serverAddr)
	if err != nil {
		log.Printf("[Client] Failed to dial: %v", err)
		events <- FinalTurnComplete{CompletedTurns: 0, Alive: []util.Cell{}}
		return
	}
	defer client.Close()
	log.Printf("[Client] Connected successfully")

	// 2. 读取初始世界状态
	filename := fmt.Sprintf("%dx%d", params.ImageWidth, params.ImageHeight)
	initialWorldBytes, err := InputPGM(filename)
	if err != nil {
		panic(err)
	}
	initialWorld := make([][]uint8, len(initialWorldBytes))
	for i := range initialWorld {
		initialWorld[i] = make([]uint8, len(initialWorldBytes[i]))
		copy(initialWorld[i], initialWorldBytes[i])
	}
	// if err != nil {
	// 	log.Printf("[Client] Warning: Failed to load PGM file %s: %v", filename, err)
	// 	// 创建默认世界
	// 	initialWorld = make([][]uint8, params.ImageHeight)
	// 	for i := range initialWorld {
	// 		initialWorld[i] = make([]uint8, params.ImageWidth)
	// 	}
	// } else {
	// 	// 转换[][]byte为[][]uint8
	// 	initialWorld = make([][]uint8, len(initialWorldBytes))
	// 	for i := range initialWorld {
	// 		initialWorld[i] = make([]uint8, len(initialWorldBytes[i]))
	// 		copy(initialWorld[i], initialWorldBytes[i])
	// 	}
	// }
	log.Printf("[Client] Initial world loaded")

	// 3. 准备参数，包含完整的初始世界状态
	args := ProcessTurnsArgs{
		Params: params,
		World:  initialWorld,
	}
	var reply ProcessTurnsReply
	var resetReply ProcessTurnsReply

	var paused bool = false
	var currentTurn int = 0

	// 计算初始活细胞
	initialAliveCells := []util.Cell{}
	for y := 0; y < params.ImageHeight; y++ {
		for x := 0; x < params.ImageWidth; x++ {
			if initialWorld[y][x] == 255 {
				initialAliveCells = append(initialAliveCells, util.Cell{X: x, Y: y})
			}
		}
	}
	log.Printf("[Client] Found %d initial alive cells", len(initialAliveCells))

	log.Printf("[Client] Params.Turns = %d", params.Turns)
	if params.Turns <= 0 {
		log.Printf("[Client] No turns to execute, finishing immediately")
		log.Printf("[Client] DEBUG: About to send FinalTurnComplete for 0 turns")
		events <- FinalTurnComplete{
			CompletedTurns: 0,
			Alive:          initialAliveCells,
		}
		log.Printf("[Client] DEBUG: Sent FinalTurnComplete for 0 turns")
		close(events)
		return
	}

	log.Printf("[Client] Starting game loop for %d turns", params.Turns)
	for i := 0; i < params.Turns; {
		currentTurn = i
		log.Printf("[Client] Turn %d/%d", i+1, params.Turns)

		// 处理按键输入
		if keyPresses != nil {
			select {
			case key := <-keyPresses:
				log.Printf("[Client] Key press received: %c", key)

				if key == 'q' {
					log.Println("[Client] Quitting...")
					if keyPresses != nil {
						saveState(client, args, events, currentTurn)
					}
					err = client.Call("LogicEngine.ResetState", args, &resetReply)
					if err != nil {
						log.Printf("[Client] ERROR: Failed to reset server: %v", err)
					}
					events <- FinalTurnComplete{
						CompletedTurns: currentTurn,
						Alive:          reply.AliveCells,
					}
					close(events)
					return
				}

				if key == 's' {
					log.Println("[Client] Save requested...")
					saveState(client, args, events, currentTurn)
				}

				if key == 'p' {
					paused = !paused
					log.Printf("[Client] Paused state toggled to: %v", paused)
					if paused {
						events <- StateChange{
							CompletedTurns: currentTurn,
							NewState:       Paused,
						}
					} else {
						events <- StateChange{
							CompletedTurns: currentTurn,
							NewState:       Executing,
						}
					}
				}
			default:
				// 没有按键，继续
			}
		}

		// 如果没有暂停，执行游戏逻辑
		if !paused {
			log.Printf("[Client] Calling ProcessSingleTurn for turn %d", i+1)
			reply = ProcessTurnsReply{}
			err = client.Call("LogicEngine.ProcessSingleTurn", args, &reply)
			if err != nil {
				log.Fatalf("[Client] RPC call failed: %v", err)
			}
			log.Printf("[Client] ProcessSingleTurn completed, got %d alive cells", len(reply.AliveCells))

			events <- AliveCellsCount{
				CellsCount:     len(reply.AliveCells),
				CompletedTurns: i + 1,
			}

			for _, cell := range reply.AliveCells {

				events <- CellFlipped{
					CompletedTurns: i + 1,
					Cell:           cell,
				}

			}

			select {
			case events <- TurnComplete{
				CompletedTurns: i + 1,
			}:
			case <-time.After(1 * time.Millisecond):
			}

			if keyPresses != nil {
				time.Sleep(50 * time.Millisecond)
			}

			i++
		} else {
			time.Sleep(100 * time.Millisecond)
		}
	}

	// 4. N 轮都完成了
	log.Println("[Client] All turns complete.")

	// 最后保存状态
	// if keyPresses != nil {
	saveState(client, args, events, params.Turns)
	// }

	// 重置服务器状态
	err = client.Call("LogicEngine.ResetState", args, &resetReply)
	if err != nil {
		log.Printf("[Client] ERROR: Failed to reset server: %v", err)
	}

	// 发送最终完成事件并关闭通道
	log.Printf("[Client] DEBUG: About to send final FinalTurnComplete")
	events <- FinalTurnComplete{
		CompletedTurns: params.Turns,
		Alive:          reply.AliveCells,
	}
	log.Printf("[Client] DEBUG: Sent final FinalTurnComplete")

	close(events)
}
