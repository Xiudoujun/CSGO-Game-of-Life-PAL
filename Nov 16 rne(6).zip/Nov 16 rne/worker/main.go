// 位于 worker/main.go (Step 6 - 最终版，修复了 newWorld/newStrip 错误)
package main

import (
	"flag" // <--- 1. 导入 "flag" 包
	"log"
	"net"
	"net/rpc"

	"uk.ac.bris.cs/gameoflife/gol"
)

// mod 是一个辅助函数
func mod(x, m int) int {
	return (x%m + m) % m
}

// calculateWorkerNeighbours... (保持不变)
func calculateWorkerNeighbours(p gol.Params, strip [][]uint8, haloUp []uint8, haloDo []uint8, x, y int) int {
	neighbours := 0
	stripHeight := len(strip)

	for i := -1; i <= 1; i++ { // y-offset (row)
		for j := -1; j <= 1; j++ { // x-offset (column)
			if i == 0 && j == 0 {
				continue // 跳过细胞自身
			}
			nx := mod(x+j, p.ImageWidth)
			var neighbourRow []uint8
			switch {
			case y == 0 && i == -1:
				neighbourRow = haloUp
			case y == stripHeight-1 && i == 1:
				neighbourRow = haloDo
			default:
				neighbourRow = strip[y+i]
			}
			if neighbourRow[nx] != 0 {
				neighbours++
			}
		}
	}
	return neighbours
}

// WorkerEngine... (保持不变)
type WorkerEngine struct{}

// -----------------------------------------------------------------
// ！！！ 拼写修复在这里 ！！！
// -----------------------------------------------------------------
// ProcessStrip... (修复了 newWorld -> newStrip)
func (we *WorkerEngine) ProcessStrip(args gol.WorkerJobArgs, reply *gol.WorkerJobReply) error {
	stripHeight := len(args.Strip)
	stripWidth := args.Params.ImageWidth
	newStrip := make([][]uint8, stripHeight)
	for i := range newStrip {
		newStrip[i] = make([]uint8, stripWidth)
	}

	for y := 0; y < stripHeight; y++ {
		for x := 0; x < stripWidth; x++ {
			neighbours := calculateWorkerNeighbours(args.Params, args.Strip, args.HaloUp, args.HaloDo, x, y)
			currentState := args.Strip[y][x]

			if currentState == 255 {
				if neighbours < 2 || neighbours > 3 {
					newStrip[y][x] = 0
				} else {
					newStrip[y][x] = 255
				}
			} else {
				if neighbours == 3 {
					newStrip[y][x] = 255
				} else {
					newStrip[y][x] = 0
				}
			}
		}
	}
	reply.StripNew = newStrip
	return nil
}

// -----------------------------------------------------------------
// ！！！ Step 6 的改动在这里 ！！！
// -----------------------------------------------------------------
// main 是 Worker 服务器的入口
func main() {
	// 2. 定义一个 'port' 标志，默认值为 8081
	portFlag := flag.String("port", "8081", "Port for the worker to listen on.")
	flag.Parse() // 解析命令行参数

	port := ":" + *portFlag // (e.g., ":8081")

	// ------------------(后面的代码和以前一样)------------------

	worker := new(WorkerEngine)

	err := rpc.Register(worker)
	if err != nil {
		log.Fatal("Failed to register RPC worker:", err)
	}

	listener, err := net.Listen("tcp", port)
	if err != nil {
		log.Fatal("Failed to listen on port", port, err)
	}
	defer listener.Close()

	log.Println("GoL Worker server listening on port", port)

	// 接受并处理连接
	rpc.Accept(listener)
}
