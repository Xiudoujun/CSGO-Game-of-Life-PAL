package gol

import (
	"fmt"
	"sync"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

type distributorChannels struct {
	events     chan<- Event
	ioCommand  chan<- ioCommand
	ioIdle     <-chan bool
	ioFilename chan<- string
	ioOutput   chan<- uint8
	ioInput    <-chan uint8
}

// distributor divides the work between workers and interacts with other goroutines.
func distributor(p Params, c distributorChannels, keyPresses <-chan rune) {

	// Create a 2D slice to store the world.
	world := make([][]uint8, p.ImageHeight)
	for i := range world {
		world[i] = make([]uint8, p.ImageWidth)
	}

	c.ioCommand <- ioInput
	c.ioFilename <- fmt.Sprintf("%dx%d", p.ImageWidth, p.ImageHeight)
	
	// Read the initial world state
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			world[y][x] = <-c.ioInput
		}
	}

	// Send initial CellFlipped events for all alive cells
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if world[y][x] == 255 {
				c.events <- CellFlipped{CompletedTurns: 0, Cell: util.Cell{X: x, Y: y}}
			}
		}
	}

	turn := 0
	state := Executing
	c.events <- StateChange{turn, state}

	// Start periodic alive cells count reporting
	aliveCountTicker := time.NewTicker(2 * time.Second)
	defer aliveCountTicker.Stop()

	// Channel to signal quit
	shouldQuit := false

	// Function to save PGM image
	saveImage := func(filename string) {
		c.ioCommand <- ioOutput
		c.ioFilename <- filename
		
		for y := 0; y < p.ImageHeight; y++ {
			for x := 0; x < p.ImageWidth; x++ {
				c.ioOutput <- world[y][x]
			}
		}

		c.ioCommand <- ioCheckIdle
		<-c.ioIdle
		
		c.events <- ImageOutputComplete{CompletedTurns: turn, Filename: filename}
	}

	// Execute all turns of the Game of Life.
	for turn < p.Turns && !shouldQuit {
		// Process key presses
		select {
		case key := <-keyPresses:
			switch key {
			case 's':
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)
			case 'q':
				shouldQuit = true
			case 'p':
				if state == Executing {
					state = Paused
				} else {
					state = Executing
				}
				c.events <- StateChange{CompletedTurns: turn, NewState: state}
			}
		default:
		}

		// If paused, block and wait for key presses
		for state == Paused && !shouldQuit {
			key := <-keyPresses
			switch key {
			case 's':
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)
			case 'q':
				shouldQuit = true
			case 'p':
				state = Executing
				c.events <- StateChange{CompletedTurns: turn, NewState: state}
			}
		}

		if shouldQuit {
			break
		}

		// Create next world state
		nextWorld := make([][]uint8, p.ImageHeight)
		for i := range nextWorld {
			nextWorld[i] = make([]uint8, p.ImageWidth)
		}

		// Calculate work distribution for workers
		rowsPerWorker := p.ImageHeight / p.Threads
		remainingRows := p.ImageHeight % p.Threads

		var wg sync.WaitGroup
		startRow := 0

		for i := 0; i < p.Threads; i++ {
			rows := rowsPerWorker
			if i < remainingRows {
				rows++
			}

			wg.Add(1)
			go func(startY, numRows int) {
				defer wg.Done()
				worker(startY, numRows, p.ImageWidth, p.ImageHeight, world, nextWorld, c.events, turn+1)
			}(startRow, rows)

			startRow += rows
		}

		wg.Wait()

		// Update world for next turn
		world = nextWorld
		turn++

		// Send turn complete event
		c.events <- TurnComplete{CompletedTurns: turn}
		
		// Check for key presses immediately after turn complete
		select {
		case key := <-keyPresses:
			switch key {
			case 's':
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)
			case 'q':
				shouldQuit = true
			case 'p':
				if state == Executing {
					state = Paused
				} else {
					state = Executing
				}
				c.events <- StateChange{CompletedTurns: turn, NewState: state}
			}
		default:
		}

		// Check for periodic alive count reporting
		select {
		case <-aliveCountTicker.C:
			aliveCount := 0
			for y := 0; y < p.ImageHeight; y++ {
				for x := 0; x < p.ImageWidth; x++ {
					if world[y][x] == 255 {
						aliveCount++
					}
				}
			}
			c.events <- AliveCellsCount{CompletedTurns: turn, CellsCount: aliveCount}
		default:
		}
		
		// Check for key presses at end of turn (non-blocking)
		select {
		case key := <-keyPresses:
			switch key {
			case 's':
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)
			case 'q':
				shouldQuit = true
			case 'p':
				if state == Executing {
					state = Paused
				} else {
					state = Executing
				}
				c.events <- StateChange{CompletedTurns: turn, NewState: state}
			}
		default:
		}
	}

	// Collect final alive cells
	var aliveCells []util.Cell
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if world[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{X: x, Y: y})
			}
		}
	}
	
	// Send FinalTurnComplete event
	c.events <- FinalTurnComplete{CompletedTurns: turn, Alive: aliveCells}
	
	// Output the final state as a PGM image
	finalFilename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
	saveImage(finalFilename)

	c.ioCommand <- ioCheckIdle
	<-c.ioIdle

	c.events <- StateChange{turn, Quitting}

	close(c.events)
}

// worker processes a portion of the world matrix
func worker(startY, numRows, width, height int, world, nextWorld [][]uint8, events chan<- Event, completedTurns int) {
	var flippedCells []util.Cell

	for y := startY; y < startY+numRows; y++ {
		for x := 0; x < width; x++ {
			neighbors := countNeighbors(x, y, width, height, world)
			currentState := world[y][x]

			if currentState == 255 { // Alive cell
				if neighbors < 2 || neighbors > 3 {
					// Dies
					nextWorld[y][x] = 0
					flippedCells = append(flippedCells, util.Cell{X: x, Y: y})
				} else {
					// Survives
					nextWorld[y][x] = 255
				}
			} else { // Dead cell
				if neighbors == 3 {
					// Becomes alive
					nextWorld[y][x] = 255
					flippedCells = append(flippedCells, util.Cell{X: x, Y: y})
				} else {
					// Stays dead
					nextWorld[y][x] = 0
				}
			}
		}
	}

	// Send flipped cells event
	if len(flippedCells) > 0 {
		events <- CellsFlipped{CompletedTurns: completedTurns, Cells: flippedCells}
	}
}

// countNeighbors counts the number of alive neighbors for a cell
func countNeighbors(x, y, width, height int, world [][]uint8) int {
	count := 0
	for dy := -1; dy <= 1; dy++ {
		for dx := -1; dx <= 1; dx++ {
			if dx == 0 && dy == 0 {
				continue // Skip the cell itself
			}
			
			// Handle toroidal (wrapped) boundaries
			nx := (x + dx + width) % width
			ny := (y + dy + height) % height
			
			if world[ny][nx] == 255 {
				count++
			}
		}
	}
	return count
}
