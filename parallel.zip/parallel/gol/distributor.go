package gol

import (
	"fmt"
	"time"

	"uk.ac.bris.cs/gameoflife/util"
)

type distributorChannels struct {
	events     chan<- Event
	ioCommand  chan<- ioCommand
	ioIdle     <-chan bool
	ioFilename chan<- string
	ioOutput   chan<- uint8
	ioInput    <-chan uint8
	keyPresses <-chan rune //base the main.go found the type of chan，rune-receive only
}

// tips:Struct--kind of Class
type worker struct {
	state        [][]uint8 //0-256
	newstate     [][]uint8
	width        int
	height       int
	startY, endY int
}

// updateState & calculateNewBoard
// fork-join reduce method
// the cells need updating is uncertainty, but the number of goroutines is fixed.
// Execute a goroutines once, write data to the done channel once, ensuring the done channel's state equal to number of goroutines.
// muti-done chan--slice done chan {}
func calculateNewBoard(worker worker, done chan []util.Cell) {
	flippedCells := []util.Cell{}
	for y := worker.startY; y < worker.endY; y++ { // startY to endY-1,i=y --image
		for x := 0; x < worker.width; x++ { //j=x
			alivecell := 0 //Counting live cells
			//for loop through the rows and column of the state board
			for dx := -1; dx <= 1; dx++ {
				for dy := -1; dy <= 1; dy++ {
					if dx == 0 && dy == 0 {
						continue
						//cell itself
					}
					//neighbor cell
					nx := x + dx
					ny := y + dy
					//Add protection against going out of bounds
					nx = (nx + worker.width) % worker.width   //worker.width = len(state[0])
					ny = (ny + worker.height) % worker.height // worker.height = len(state)

					if worker.state[ny][nx] == 255 {
						alivecell++
					}
				}
			}
			//Cell Status Update Determination
			if worker.state[y][x] == 255 { //current status
				if alivecell < 2 || alivecell > 3 {
					flippedCells = append(flippedCells, util.Cell{X: x, Y: y}) //Collect cell information for state reversal.
					worker.newstate[y][x] = 0
				} else {
					worker.newstate[y][x] = 255
				}
			} else { //Revitalizing dead cells
				if alivecell == 3 {
					flippedCells = append(flippedCells, util.Cell{X: x, Y: y}) //flippixel，window./go, loop.go
					worker.newstate[y][x] = 255
				} else {
					worker.newstate[y][x] = 0
				}
			}
		}
	}
	//the end of the loop execution
	done <- flippedCells // write all reversed cells of the current goroutines to the done channel.
}

func getAliveCellsOnBoard(state [][]uint8, width, height int) []util.Cell {
	aliveCells := []util.Cell{} //slice of alive cells
	//count:=0 //just use len(aliveCells[]) then a new count
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			if state[y][x] == 255 {
				aliveCells = append(aliveCells, util.Cell{Y: y, X: x})
				//count++
			}
		}
	}
	return aliveCells
}

// call Io goroutines read board
func readInitialState(p Params, d distributorChannels) [][]uint8 {
	d.ioCommand <- ioInput
	d.ioFilename <- fmt.Sprintf("%vx%v", p.ImageWidth, p.ImageHeight) //根据util_test
	state := make([][]uint8, p.ImageHeight)
	for i := range state {
		state[i] = make([]uint8, p.ImageWidth)
	}
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			state[y][x] = <-d.ioInput //from d.ioInput channel read pixel
		}
	}
	return state //return uint8[][] matrix data
}

// distributor divides the work between workers and interacts with other goroutines.
func distributor(p Params, c distributorChannels) {
	//执行主体
	// TODO: Create a 2D slice to store the world.

	state := readInitialState(p, c)
	// initial the cell board

	pause := false   // continue or not
	quit := false    //quit
	saveQuit := true //non quit auto save

	// Initialization cell board
	alievecells := getAliveCellsOnBoard(state, p.ImageWidth, p.ImageHeight)
	for _, cell := range alievecells {
		c.events <- CellFlipped{CompletedTurns: 0, Cell: cell}
	}

	turn := 0

	c.events <- StateChange{turn, Executing}

	//Function to save PGM image
	//helper functions for image output
	saveImage := func(filename string) {
		c.ioCommand <- ioOutput
		c.ioFilename <- filename

		for y := 0; y < p.ImageHeight; y++ {
			for x := 0; x < p.ImageWidth; x++ {
				c.ioOutput <- state[y][x] // state --world
			}
		}
		//check command to ensure disk write completion
		c.ioCommand <- ioCheckIdle //finish?
		<-c.ioIdle                 //finish.
		//write and send ImageOutputComplete event；s & q
		c.events <- ImageOutputComplete{CompletedTurns: turn, Filename: filename}
	}

	//Initialization
	ticker := time.NewTicker(2 * time.Second) //time ticker，each 2 seconds，tp ticker.C, for alive tests
	for turn < p.Turns && !quit {
		select { //which channel is ready
		//monitor event from users' key press
		case key := <-c.keyPresses: // only data in c.keyPresses
			switch key { //find case
			case 'p': //pause
				if !pause {
					pause = true
					c.events <- StateChange{CompletedTurns: turn, NewState: Paused} //p，statue update stop -true
				} else {
					pause = false
					c.events <- StateChange{CompletedTurns: turn, NewState: Executing} //if stop，statue update execute -false, event.go
				}
			case 's': //save
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)

			case 'q': //quit
				filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
				saveImage(filename)
				quit = true      //exit loop
				saveQuit = false // false to auto save
			}

		case <-ticker.C:
			aliveCount := getAliveCellsOnBoard(state, p.ImageWidth, p.ImageHeight)
			c.events <- AliveCellsCount{CompletedTurns: turn, CellsCount: len(aliveCount)}

		default:
			if !pause {
				//buffered channel
				done := make(chan []util.Cell, p.Threads)

				//new cell board
				newState := make([][]uint8, p.ImageHeight) // ImageHeight-column
				for i := 0; i < p.ImageHeight; i++ {       //i=y
					newState[i] = make([]uint8, p.ImageWidth)
				}

				// Calculate work distribution for workers
				// Round up to determine how many rows each worker has.
				rowsPerWorker := p.ImageHeight / p.Threads
				remainingRows := p.ImageHeight % p.Threads

				startY := 0 //--startRow
				for t := 0; t < p.Threads; t++ {
					rows := rowsPerWorker //--numRows
					if t < remainingRows {
						rows++
					}

					endY := startY + rows //--startRow + numRows
					// rows == 0，calculateNewBoard y from startY to endY, not overstep boundaries, like -1

					// go work1
					// Initialize a new worker，goroutines numbers means how many worker we have
					// updating the board with a single goroutine is too slow, each goroutine to handle a calculateNewBoard func.
					// done is the result for all updated cells under a specific calculateNewBoard goroutines.
					go calculateNewBoard(worker{
						startY:   startY,
						endY:     endY,
						newstate: newState, // initialization has not yet updated the new board.
						state:    state,    // board completed in the last round
						width:    p.ImageWidth,
						height:   p.ImageHeight,
					}, done)
					//}, done, threadRecord)
					startY = endY
				}

				alievecells := []util.Cell{}
				for i := 0; i < p.Threads; i++ {
					flippedCells := <-done
					alievecells = append(alievecells, flippedCells...)
					//Check whether all threads have completed their tasks, if slice done confirms sufficient goroutines, then finish.
				}
				close(done)
				//done record the cells need to be reversed

				c.events <- CellsFlipped{CompletedTurns: turn, Cells: alievecells}
				state = newState
				turn++
				c.events <- TurnComplete{CompletedTurns: turn}

			} else {
				time.Sleep(10 * time.Millisecond) // not occupy CPU
			}
		}
	}
	finalCells := getAliveCellsOnBoard(state, p.ImageWidth, p.ImageHeight)

	// send after all turns completed
	c.events <- FinalTurnComplete{CompletedTurns: turn, Alive: finalCells}

	// TODO: Execute all turns of the Game of Life.

	// TODO: Report the final state using FinalTurnCompleteEvent.

	// Make sure that the Io has finished any output before exiting.
	if saveQuit { //循环结束自动保存
		filename := fmt.Sprintf("%dx%dx%d", p.ImageWidth, p.ImageHeight, turn)
		saveImage(filename)
	}

	c.events <- StateChange{turn, Quitting} //event is Quitting

	// Close the channel to stop the SDL goroutine gracefully. Removing may cause deadlock.
	close(c.events)
}
